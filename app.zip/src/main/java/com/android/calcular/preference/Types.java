package com.android.calcular.preference;

import java.util.ArrayList;
import java.util.List;

/**
 * project name: Calcular
 * Date 2021/10/24 14:41
 *
 * @PackageName: com.android.calcular.preference
 * @ClassName: Types
 * @Author: Likailing
 * @Version:
 * @Desciption:不同年级对应的题目类型
 */
public class Types {
    public static final String[] ORAL_GRADE_1={"10以内加减法","10以内连加、连减","10以内加减混合","20以内加减混合","100以内的加减混合","100以内的减法","100以内的加法"};
    public static final String[] ORAL_GRADE_2={"加法，减法，混合加减","9x9乘法","10以内乘加，乘减","100以内除以个位数。得数需为整数","除加，除减","100-1000的加减法"};
    public static final String[] ORAL_GRADE_3={"一位数除两位数，结果为整数","一位数除三位数，结果为整数","两位数乘一位数","两位数相乘","含小数的加减法"};
    public static final String[] ORAL_GRADE_4={"含括号的三运算符","含小数的加，减法"};
    public static final String[] ORAL_GRADE_5={"除数是整数,算式可除的小数除法","小数乘，除法","同分母的分数加，减法","异分母的加，减法","含分母的加减混合运算"};
    public static final String[] ORAL_GRADE_6={"分数乘整数","分数乘分数","含括号的三运算符"};
    public static final String[] HAND_GRADE_1={};
    public static final String[] HAND_GRADE_2={};
    public static final String[] HAND_GRADE_3={};
    public static final String[] HAND_GRADE_4={};
    public static final String[] HAND_GRADE_5={};
    public static final String[] HAND_GRADE_6={};


}
