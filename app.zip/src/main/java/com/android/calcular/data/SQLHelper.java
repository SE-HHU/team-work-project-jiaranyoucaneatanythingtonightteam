package com.android.calcular.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 * project name: Calcular
 * Date 2021/10/19 16:24
 *
 * @PackageName: com.android.calcular.data
 * @ClassName: SQLDao
 * @Author: Likailing
 * @Version:
 * @Desciption:数据库启动帮助类
 */
public class SQLHelper extends SQLiteOpenHelper {
    /*
    数据库的名称
     */
    private static String name="caldb.db";

    public SQLHelper(@Nullable Context context, @Nullable String name, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "create table StudentInfo(stu_grade integer,stu_accuracy double,stu_questionCount integer,stu_date date)";
        sqLiteDatabase.execSQL(sql);

        sql = "create table StudyHistory(his_code integer,his_time datetime,his_timeCost int,his_isFinished boolean,his_score integer,his_wrong integer,his_type text,his_amount integer)";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists StudentInfo");
        sqLiteDatabase.execSQL("drop table if exists StudyHistory");
        onCreate(sqLiteDatabase);
    }

}
