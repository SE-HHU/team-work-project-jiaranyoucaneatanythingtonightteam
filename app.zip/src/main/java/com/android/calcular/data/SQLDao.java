package com.android.calcular.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.android.calcular.MyApplication;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;

/**
 * project name: Calcular
 * Date 2021/10/24 12:21
 *
 * @PackageName: com.android.calcular.data
 * @ClassName: SQLDao
 * @Author: Likailing
 * @Version:
 * @Desciption:数据库操作类
 */
public class SQLDao {
    SQLHelper sqlHelper;
    SQLiteDatabase database;
    public SQLDao(Context context){
        sqlHelper =new SQLHelper(context,"testdb.db",2);
        database= sqlHelper.getWritableDatabase();
    }

    /**
    *@Params: []
    *@Return: List
    *@Author: Likailing
    *@Date: 2021/10/24 12:31
    *@Desciption:获取最新的学生信息
    */
    public List getNewestStuInfo(){
        List info=new ArrayList();
        Cursor cursor=database.query("StudentInfo",new String[]{"stu_grade","stu_accuracy","stu_questionCount","stu_date"},null,null,null,null,null);
        if(cursor.moveToLast()){
            info.add(cursor.getInt(0));
            info.add(cursor.getDouble(1));
            info.add(cursor.getInt(2));
            info.add(cursor.getLong(3));
        }
        Log.i("sql",info.toString());
        return info;
    }
    /**
    *@Params: []
    *@Return: List
    *@Author: Likailing
    *@Date: 2021/10/24 12:32
    *@Desciption:获取所有的学生信息
    */
    public List getAllStuInfo(){
        List<List> infos=new ArrayList<>();
        Cursor cursor=database.query("StudentInfo",new String[]{"stu_grade","stu_accuracy","stu_questionCount","stu_date"},null,null,null,null,null);
        while(cursor.moveToNext()){
            List info=new ArrayList();
            info.add(cursor.getInt(0));
            info.add(cursor.getDouble(1));
            info.add(cursor.getInt(2));
            info.add(cursor.getLong(3));
            infos.add(info);
        }
        cursor.close();
        Log.i("sql",infos.toString());
        return infos;
    }
    /**
    *@Params: []
    *@Return: java.util.List
    *@Author: Likailing
    *@Date: 2021/10/24 13:39
    *@Desciption:获取所有的学习记录
    */
    public List<List> getAllStudyRecords(){
        List<List> records=new ArrayList<>();
        Cursor cursor=database.query("StudyHistory",new String[]{"his_code","his_time","his_timeCost","his_isFinished","his_score","his_wrong","his_type","his_amount"},null,null,null,null,null);
        while(cursor.moveToNext()){
            List record=new ArrayList();
            record.add(cursor.getInt(0));
            record.add(cursor.getLong(1));
            record.add(cursor.getInt(2));
            record.add(cursor.getInt(3));
            record.add(cursor.getInt(4));
            record.add(cursor.getInt(5));
            record.add(cursor.getString(6));
            record.add(cursor.getInt(7));
            records.add(record);
        }
        cursor.close();
        Log.i("sql",records.toString());
        return records;
    }
    /**
    *@Params: []
    *@Return: java.util.List<java.lang.Integer>
    *@Author: Likailing
    *@Date: 2021/11/6 18:28
    *@Desciption:获取保存的所有记录的编码
    */
    public List<Integer> getAllRecordCodes(){
        List<List> lists=getAllStudyRecords();
        List<Integer> codeList=new ArrayList<>();
        Iterator<List> iterator=lists.iterator();
        while(iterator.hasNext()){
            int code=(Integer)iterator.next().get(0);
            if(!codeList.contains(code)){
                codeList.add(code);
            }

        }

        return codeList;
    }

    public List<Integer> getThisWeekRecordCodes(){
        List<List> lists=getAllStudyRecords();
        List<Integer> codeList=new ArrayList<>();
        Iterator<List> iterator=lists.iterator();
        while(iterator.hasNext()){
            List next=iterator.next();
            int code=(Integer)next.get(0);
            long time=(Long)next.get(1);
            long current=System.currentTimeMillis();
            if(!codeList.contains(code)&&time>=current-604800000){
                codeList.add(code);
            }

        }

        return codeList;
    }

    public List getNewestRecord(){
        List record=new ArrayList<>();
        Cursor cursor=database.query("StudyHistory",new String[]{"his_code","his_time","his_timeCost","his_isFinished","his_score","his_wrong","his_type","his_amount"},null,null,null,null,null);
        if(cursor.moveToLast()){
            record.add(cursor.getInt(0));
            record.add(cursor.getLong(1));
            record.add(cursor.getInt(2));
            record.add(cursor.getInt(3));
            record.add(cursor.getInt(4));
            record.add(cursor.getInt(5));
            record.add(cursor.getString(6));
            record.add(cursor.getInt(7));
        }
        cursor.close();
        Log.i("sql",record.toString());
        return record;
    }
    /**
    *@Params: [datetime]
    *@Return: java.util.Date
    *@Author: Likailing
    *@Date: 2021/10/24 12:39
    *@Desciption:获取北京时间
    */
    public String getBeijingTime(Date date){
        // 北京
        SimpleDateFormat bjSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 设置北京时区
        bjSdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));

        return bjSdf.format(date);
    }
    /**
    *@Params: [grade, accuracy, questionCount, date]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:15
    *@Desciption:增加学生信息记录
    */
    public void addStuInfo(int grade,double accuracy,int questionCount,Date date){
        Date lastDate=null;
        if(getNewestStuInfo().size()>0){
           lastDate=new Date((long)getNewestStuInfo().get(3));
        }

        ContentValues info=new ContentValues();
        info.put("stu_grade", grade);
        info.put("stu_accuracy",accuracy);
        info.put("stu_questionCount",questionCount);
        info.put("stu_date",date.getTime());
        if(lastDate==null||lastDate.getDate()!=date.getDate()){//如果上条记录不为同一天
            database.insert("StudentInfo",null,info);
        }else{
            database.update("StudentInfo",info,"stu_date=?",new String[]{String.valueOf(getNewestStuInfo().get(3))});
        }

    }
    /**
    *@Params: [code, time, timeCost, isFinished, score, wrong, type]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:24
    *@Desciption:增加学习记录
    */
    public void addStudyRecord(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        ContentValues record=new ContentValues();
        record.put("his_code",code);
        record.put("his_time",time);
        record.put("his_timeCost",timeCost);
        record.put("his_isFinished",isFinished);
        record.put("his_score",score);
        record.put("his_wrong",wrong);
        record.put("his_type",type);
        record.put("his_amount",amount);
        database.insert("StudyHistory",null,record);
    }
    /**
    *@Params: [code, time, timeCost, isFinished, score, wrong, type, amount]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 17:07
    *@Desciption:编辑某条记录，根据his_code寻找记录
    */
    public void editStudyRecord(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        ContentValues record=new ContentValues();
        record.put("his_code",code);
        record.put("his_time",time);
        record.put("his_timeCost",timeCost);
        record.put("his_isFinished",isFinished);
        record.put("his_score",score);
        record.put("his_wrong",wrong);
        record.put("his_type",type);
        record.put("his_amount",amount);
        database.update("StudyHistory",record,"his_code=?",new String[]{String.valueOf(code)});
    }


    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:39
    *@Desciption:清空所有记录
    */
    public void clearData(){
        database.execSQL("delete from StudentInfo");
        database.execSQL("delete from StudyHistory");
    }
    /**
     *
     * @return
     * @Desciption: 查找错误最多的题目类型
     */
    public String getworstType(){
//        ContentValues record=new ContentValues();
        String[] worstTypes = new String[]{"00","11","12","13","14","15","16","17","18","19","21","22","23","24","25","26","31","32","33","34","35","41","42","51","52","53","54","55","61","62","63"};
        TreeMap<String,Integer> map=new TreeMap<>();
        int index =0;
        String maxType="00";
        // 题目类型数组/集合
        for(index=0;index<worstTypes.length;index++){
            int number =0;
            //填写题目类型 String
            Iterator Iterator = getworseNumber(worstTypes[index],"his_wrong").iterator();
            while (Iterator.hasNext()){
                number =number+(int)Iterator.next();
            }
            map.put(worstTypes[index],number);
            if(number>map.get(maxType)){
                maxType=worstTypes[index];
            }
        }
//        比较worstTypes中最多的值，取key赋值给worstType
        Log.i("sql","错题书最多的类型"+maxType);
        return maxType;
    }

    public Set<Map.Entry<String,Integer>> getWrongTypes(){
        String[] worstTypes = new String[]{"00","11","12","13","14","15","16","17","18","19","21","22","23","24","25","26","31","32","33","34","35","41","42","51","52","53","54","55","61","62","63"};
        TreeMap<String,Integer> map=new TreeMap<>();
        int index =0;
        for(index=0;index<worstTypes.length;index++){// 题目类型数组/集合
            int number =0;
            Iterator iterator = getworseNumber(worstTypes[index],"his_wrong").iterator();//填写题目类型 String
            while (iterator.hasNext()){
                number =number+(int)iterator.next();
            }
            if(number>0){
                map.put(worstTypes[index],number);
            }

        }
        Set<Map.Entry<String,Integer>> entrySet=map.entrySet();
        Log.i("sql","含有错误的类型"+entrySet.toString());
        return entrySet;

    }

    public Set<Map.Entry<String,Float>> getWrongAccuracies(){
        String[] worstTypes = new String[]{"00","11","12","13","14","15","16","17","18","19","21","22","23","24","25","26","31","32","33","34","35","41","42","51","52","53","54","55","61","62","63"};
        TreeMap<String,Float> map=new TreeMap<>();
        int index =0;
        for(index=0;index<worstTypes.length;index++){// 题目类型数组/集合
            int wrong =0;
            int total=0;
            Iterator iterator1 = getworseNumber(worstTypes[index],"his_wrong").iterator();//填写题目类型 String
            Iterator iterator2=getworseNumber(worstTypes[index],"his_amount").iterator();
            while (iterator1.hasNext()){
                wrong =wrong+(int)iterator1.next();
                total=total+(int)iterator2.next();
            }
            if(wrong>0){
                map.put(worstTypes[index],(float)wrong/total);
            }

        }
        Set<Map.Entry<String,Float>> entrySet=map.entrySet();
        Log.i("sql","含有错误的类型"+entrySet.toString());
        return entrySet;

    }

    /**
     *
     * @param Type 题目类型
     * @return
     * @Description： 查找指定类型的指定类型数量集
     */
    public List<Integer> getworseNumber(String Type,String amountType){
//        String sql = "select his_wrong from StudyHistory where his_type = '"+Type+"'";
//        Cursor cr = database.rawQuery(sql,null);
//        while(cr.moveToNext()){
//            int index = cr.getInt(0);
//            worselist.add(index);
//        }
//        return worselist;
        List<Integer> list = new ArrayList<>();
        String sql = "select * from StudyHistory where his_type = '"+Type+"'";
        Cursor cr = database.rawQuery(sql,null);
        while(cr.moveToNext()){
            int index =Integer.parseInt( cr.getString(cr.getColumnIndex(amountType)-1+1));
            list.add(index);
        }
        Log.i("sql","题目数量集"+Type+list.toString());
        return list;
    }


    /**
     *@Desciption:获取当天的正确率
     */
    public float getTodayAccuracy(){
        Date nowDate=new Date();
        int date = nowDate.getDate();
        int month=nowDate.getMonth();
        int year = nowDate.getYear();
        int wrongnumber  =0;
        int amount =0;
        List list = getAllStudyRecords();
        Iterator<List> it = list.iterator();
        while (it.hasNext()){
            List info=it.next();
            Date tDate=new Date((Long)info.get(1));
            if(tDate.getDate()==date &&tDate.getMonth()==month &&tDate.getYear()==year) {
                wrongnumber += (Integer) info.get(5);
                amount += (Integer) info.get(7);
            }
        }
        if(amount==0){
            return -1f;
        }
        Log.i("sql","正确率"+String.valueOf((float) (amount-wrongnumber)/amount));
        return (float) (amount-wrongnumber)/amount;
    }

    /**
     * @Desciption:获取当天的正确题目
     * @return
     */
    public int getTodayamout() {
        Date nowDate = new Date();
        int date = nowDate.getDate();
        int month = nowDate.getMonth();
        int year = nowDate.getYear();
        int amount = 0;
        List list = getAllStudyRecords();
        Iterator<List> it = list.iterator();
        while (it.hasNext()) {
            List info = it.next();
            Date tDate = new Date((Long) info.get(1));
            if (tDate.getDate() == date && tDate.getMonth() == month && tDate.getYear() == year) {
                amount += (Integer) info.get(7);
            }
        }
        return amount;
    }

    /**
     * @Desciption:获取一直以来总的正确率
     * @return
     */
    public float getAccuracy(){
        int turenumber = 0;
        int wrongnumber =0;
        List list = getAllStudyRecords();
        Iterator<List> it = list.iterator();
        while (it.hasNext()){
            List info = it.next();
            wrongnumber += (Integer) info.get(5);
            turenumber +=(Integer) info.get(7);
        }
        if(turenumber==0){
            return -1f;
        }
        Log.i("sql","全部正确率"+String.valueOf((float) (turenumber-wrongnumber)/turenumber));
        return  (float) (turenumber-wrongnumber)/turenumber;
    }
}
