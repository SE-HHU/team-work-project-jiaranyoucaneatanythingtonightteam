package com.android.calcular.service;

import java.util.*;

/**
  *Date 2021/9/28 22:32
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 用于检查题目集对错与重复的服务类
  */
public class CheckerService {
    /**
     * 错误题号
     */
    List<Integer> wrongs=new ArrayList<Integer>();
    /**
     * 重复题目组
     */
    List<Integer[]> repeats=new ArrayList<Integer[]>();
    /**
     * 待检查的题目集合
     */
    private List<ExpressionWrapper> checkList=new ArrayList<ExpressionWrapper>();


/**
*@Params: []
*@Return: java.lang.String
*@Author: Likailing
*@Date: 2021/9/28 22:46
*@Desciption: 获取检查后的信息文本
*/
    public String getCheckInfo(){
        StringBuilder outer=new StringBuilder();
        outer.append("Correct:");
        StringBuilder corrects=new StringBuilder();
        int count=0;
        for(int i=0;i<checkList.size();i++){
            if(!wrongs.contains(i+1)){
                count++;
                corrects.append(i+1);
                //如果不是最后一个正确,则输出逗号
                if(count!=checkList.size()-wrongs.size()){
                    corrects.append(',');
                }
            }
        }
        outer.append(count);
        outer.append('(');
        outer.append(corrects);
        outer.append(')');
        outer.append('\n');
        outer.append("Wrong:");
        outer.append(wrongs.size());
        outer.append('(');
        Iterator<Integer> wrongIter=wrongs.iterator();
        count=0;
        while(wrongIter.hasNext()){
            count++;
            outer.append(wrongIter.next());
            if(count!=wrongs.size()){
                outer.append(',');
            }
        }
        outer.append(')');
        outer.append('\n');
        outer.append("Repeat:"+repeats.size());

        if(repeats.size()>0){
            outer.append('\n');
            outer.append("RepeatDetail:");
            outer.append('\n');
            Iterator<Integer[]> iterator=repeats.iterator();
            count=0;
            while(iterator.hasNext()){
                count++;
                outer.append("("+count+")");
                Integer[] ints=iterator.next();
                outer.append(ints[0]+","+checkList.get(ints[0]-1).getQuest()+" Repeat "+ints[1]+","+checkList.get(ints[1]-1).getQuest());
                outer.append('\n');
            }
        }
        return outer.toString();
    }
    /**
    *@Params: [exercise, answer]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 22:47
    *@Desciption: 解析题目与答案文本，保存检查信息
    */
    static final char DOT='.';
    public void parsrFile(String exercise,String answer){
        Scanner exeScanner=new Scanner(exercise);
        Scanner ansScanner=new Scanner(answer);
        int count=0;
        while(exeScanner.hasNextLine()){
            count++;
            String line=exeScanner.nextLine();
            String ans=ansScanner.nextLine();

            ExpressionWrapper expressionWrapper =new ExpressionWrapper(line);
            System.out.println(expressionWrapper);
            checkList.add(expressionWrapper);
            int index=0;
            while(ans.charAt(index)!=DOT){
                index++;
            }
            index++;
            int son=0,mother=1;
            FractionWrapper inputAnswer;
            StringBuilder nums=new StringBuilder();
            while(index<ans.length()){
                if(ans.charAt(index)=='/'){
                    son=Integer.parseInt(nums.toString());
                    nums=new StringBuilder();
                    index++;
                    while(index<ans.length()){
                        nums.append(ans.charAt(index));
                        index++;
                    }
                    mother=Integer.parseInt(nums.toString());
                    nums=new StringBuilder();

                }else if(ans.charAt(index)!=' '){
                    nums.append(ans.charAt(index));
                    index++;
                }else{
                    index++;
                }


            }
            if(son==0&&nums.length()>0){
                son=Integer.parseInt(nums.toString());
            }
            inputAnswer=new FractionWrapper(son,mother);
            if(!inputAnswer.equals(expressionWrapper.result)){
                wrongs.add(count);
            }
        }

        List<ExpressionWrapper> copyList = new ArrayList<ExpressionWrapper>(Arrays.asList(new ExpressionWrapper[checkList.size()]));
        Collections.copy(copyList,checkList);

        while(copyList.size()>0){
            ExpressionWrapper expressionWrapper =copyList.get(0);
            copyList.remove(0);
            if(copyList.contains(expressionWrapper)){
                int index=copyList.indexOf(expressionWrapper);
                Integer[] ints =new Integer[2];
                ints[0]= expressionWrapper.number;
                ints[1]=copyList.get(index).number;
                copyList.remove(index);
                repeats.add(ints);
            }
        }

    }

    public boolean[] checkAnswer(List<ExpressionWrapper> expList,List<FractionWrapper> answers){
        Iterator<FractionWrapper> iteratorFraction=answers.iterator();
        Iterator<ExpressionWrapper> iteratorExpression=expList.iterator();
        boolean[] checks=new boolean[expList.size()];
        int index=0;
        while(iteratorExpression.hasNext()){
            checks[index]=iteratorExpression.next().result.equals(iteratorFraction.next());
            index++;
        }
        System.out.println(Arrays.toString(checks));
        return checks;
    }
}
