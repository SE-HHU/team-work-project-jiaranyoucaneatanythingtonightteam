package com.android.calcular.service;

import android.content.Context;
import android.icu.text.IDNA;
import android.util.Log;

import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

/**
 * project name: Calcular
 * Date 2021/10/26 16:33
 *
 * @PackageName: com.android.calcular.service
 * @ClassName: InfoAccessService
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class InfoAccessService {
    private Context context;
    public InfoAccessService(Context context){
        this.context=context;
    }
    /**
    *@Params: [code, expList, answers]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 16:56
    *@Desciption: 将题目、用户输入的答案以及正确情况保存在文件中
    */
    public void printQuestions(int code,List<ExpressionWrapper> expList,List<FractionWrapper> answers){
        FileDao fileDao=new FileDao();
        Iterator<ExpressionWrapper> expListIterator = expList.iterator();
        Iterator<FractionWrapper> answersIterator = answers.iterator();
        StringBuilder strArrStrings = new StringBuilder();
        if(answers.size()>0){

            int index =0;//记录题目序号
            while(expListIterator.hasNext()){
                index++;
                ExpressionWrapper exp = expListIterator.next();
                FractionWrapper answer = answersIterator.next();
                if(exp.result.equals(answer)){
                    strArrStrings.append(index+". "+exp.getQuest()+"="+answer+"T"+"\n");
                }else if(!exp.result.equals(answer)&&answer!=null){
                    strArrStrings.append(index+". "+exp.getQuest()+"="+answer+"F"+"\n");
                }else{
                    strArrStrings.append(index+". "+exp.getQuest()+"\n");
                }
            }
            String message = strArrStrings.toString();
            fileDao.printFile("h"+code,message);
        }else{
            int index =0;//记录题目序号
            while(expListIterator.hasNext()){
                index++;
                    strArrStrings.append(index+". "+expListIterator.next().getQuest()+"="+"\n");
            }
            String message = strArrStrings.toString();
            System.out.println("打印："+message);
            fileDao.printFile("h"+code,message);
        }


    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 16:57
    *@Desciption:将学习记录信息保存在数据库中,记录编号第一次出现时创建时新建记录，编号已存在时编辑过去的记录
    */
    public void saveRecordInfo(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        //TODO
        SQLDao sqlDao=new SQLDao(context);
        boolean addsql = true;
        if(sqlDao.getAllStudyRecords().isEmpty()){
            sqlDao.addStudyRecord(code,time,timeCost,isFinished,score,wrong,type,amount);
        }
        else{
            Iterator<List> L = sqlDao.getAllStudyRecords().iterator();
            while (L.hasNext()){
                if(((Integer) (L.next().get(0))).equals(new Integer(code))){
                    addsql=false;
                    break;
                }
            }
            if(addsql) {
                sqlDao.addStudyRecord(code, time, timeCost, isFinished, score, wrong, type, amount);
            }
            else {
                sqlDao.editStudyRecord(code,time,timeCost,isFinished,score,wrong,type,amount);
            }
        }
    }
    /**
    *@Params: [grade, accuracy, questionCount, date]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 17:12
    *@Desciption:保存学生用户信息到数据库中
    */
    public void saveStudentInfo(int grade, double accuracy, int questionCount, Date date){
        SQLDao sqlDao=new SQLDao(context);
            sqlDao.addStuInfo(grade,accuracy,questionCount,date);
    }

    public void saveStudentInfo(){
        SQLDao sqlDao=new SQLDao(context);
        int grade=(Integer)sqlDao.getNewestStuInfo().get(0);
        double accuracy = sqlDao.getTodayAccuracy();
        int questionCount = sqlDao.getTodayamout();
        sqlDao.addStuInfo(grade,accuracy,questionCount,new Date());
    }

    /**
    *@Params: []
    *@Return: long
    *@Author: Likailing
    *@Date: 2021/10/26 17:15
    *@Desciption:获取当前的时间（毫秒）
    */
    private long getCurrentTimeLong(){
        return System.currentTimeMillis();
    }
    /**
    *@Params: []
    *@Return: java.util.Date
    *@Author: Likailing
    *@Date: 2021/10/26 17:15
    *@Desciption:获取当前的时间（Date对象）
    */
    private Date getCurrentTimeDate(){
        Date date=new Date(System.currentTimeMillis());
        return date;
    }
    /**
    *@Params: [id]
    *@Return: java.util.List<com.android.calcular.service.ExpressionWrapper>
    *@Author: Likailing
    *@Date: 2021/11/6 15:20
    *@Desciption:获取保存在文件中的题目集合
    */
    public List<ExpressionWrapper> getRecordQuestions(int id){
        //TODO
        FileDao fileDao=new FileDao();
        List<ExpressionWrapper> expList=new ArrayList<>();
        String text=fileDao.getText("h"+id);
        Scanner scanner=new Scanner(text);
        while(scanner.hasNextLine()){
            expList.add(new ExpressionWrapper(scanner.nextLine()));
        }
        Log.i("File","读取到的题目:"+expList.toString());
        return expList;
    }
    /**
    *@Params: []
    *@Return: java.util.List<java.lang.Integer>
    *@Author: Likailing
    *@Date: 2021/11/11 21:43
    *@Desciption:获取过去一周的每日做题数量
    */
    public List<Integer> getThisWeekCounts(){
        List<Integer> countList=new ArrayList<>(7);
        for(int i=0;i<7;i++){
            countList.add(0);
        }
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis();
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            Date iDate=new Date((long)info.get(3));
            Date prev7=new Date(now-604800000);
            if((iDate.getDate()>prev7.getDate()||(iDate.getMonth()>prev7.getMonth())||(iDate.getYear()>prev7.getYear()))){
                if(iDate.getDay()!=0){
                    countList.set(iDate.getDay()-1,new Integer((int)info.get(2)));
                }else{
                    countList.set(6,new Integer((int)info.get(2)));
                }

            }else{
                break;
            }
        }
        Log.i("sql",countList.toString());
        return countList;
    }
    public int getThisWeekTotalCount(){
        int count=0;
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis();
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            Date iDate=new Date((long)info.get(3));
            Date prev7=new Date(now-604800000);
            if((iDate.getDate()>prev7.getDate()||(iDate.getMonth()>prev7.getMonth())||(iDate.getYear()>prev7.getYear()))){
                count+=new Integer((int)info.get(2));
            }else{
                break;
            }
        }
        Log.i("sql","本周题目总数:"+count);
        return count;
    }

    public int getLastWeekTotalCount(){
        int count=0;
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis()-604800000;
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            long iDate=(long)info.get(3);
            if(now-iDate<604800000&&now-iDate>0){
                count+=new Integer((int)info.get(2));
            }else{
                break;
            }
        }
        Log.i("sql","上周题目总数:"+count);
        return count;
    }

    public float getLastWeekTotalAccuracy(){
        float count=0f;
        int total=0;
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis()-604800000;
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            long iDate=(long)info.get(3);
            if(now-iDate<604800000&&now-iDate>0){
                count+=new Float((double)info.get(1))*(Integer)info.get(2);
                total+=(Integer)info.get(2);
            }else{
                break;
            }
        }
        if(total==0){
            return 0f;
        }
        Log.i("sql","上周总正确率:"+count/total);
        return count/total;
    }
    /**
    *@Params: []
    *@Return: java.util.List<java.lang.Integer>
    *@Author: Likailing
    *@Date: 2021/11/11 22:22
    *@Desciption:获取过去一周的正确率
    */
    public List<Float> getThisWeekAccuracies(){
        //TODO
        List<Float> countList=new ArrayList<>(7);
        for(int i=0;i<7;i++){
            countList.add(0.0f);
        }
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis();
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            Date iDate=new Date((long)info.get(3));
            Date prev7=new Date(now-604800000);
            if((iDate.getDate()>prev7.getDate()||(iDate.getMonth()>prev7.getMonth())||(iDate.getYear()>prev7.getYear()))){
                if(iDate.getDay()!=0){
                    countList.set(iDate.getDay()-1,new Float((double)info.get(1)));
                }else{
                    countList.set(6,new Float((double)info.get(1)));
                }


            }else{
                break;
            }
        }

        Log.i("sql",countList.toString());
        return countList;
    }

    public float getThisWeekTotalAccuracy(){
        float count=0f;
        int total=0;
        SQLDao sqlDao=new SQLDao(context);
        List<List> infos=sqlDao.getAllStuInfo();
        ListIterator<List> iterator=infos.listIterator();
        while(iterator.hasNext()){
            iterator.next();
        }
        long now=System.currentTimeMillis();
        while(iterator.hasPrevious()){
            List info=iterator.previous();
            Date iDate=new Date((long)info.get(3));
            Date prev7=new Date(now-604800000);
            if((iDate.getDate()>prev7.getDate()||(iDate.getMonth()>prev7.getMonth())||(iDate.getYear()>prev7.getYear()))){
                count+=new Float((double)info.get(1))*(Integer)info.get(2);
                total+=(Integer)info.get(2);
            }else{
                break;
            }
        }
        if(total==0){
            return 0f;
        }
        Log.i("sql","本周总正确率:"+count/total);
        return count/total;
    }
    /**
    *@Params: [a]
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/11/13 10:36
    *@Desciption:
    */
    public String getType(String a){
        switch (a){
            case "00":
                return "一键练习";
            case "11":
                return "5以内加法";
            case "12":
                return "5以内减法";
            case "13":
                return "10以内加减法";
            case "14":
                return "10以内连加、连减";
            case "15":
                return "10以内加减混合";
            case "16":
                return "20以内加减混合";
            case "17":
                return "100以内的加减混合";
            case "18":
                return "100以内的减法";
            case "19":
                return "100以内的加法";
            case "21":
                return "加法，减法，混合加减";
            case "22":
                return "9x9乘法";
            case "23":
                return "10以内乘加，乘减";
            case "24":
                return "100以内除以个位数。得数需为整数";
            case "25":
                return "除加，除减";
            case "26":
                return "100-1000的加减法";
            case "31":
                return "一位数除两位数，结果为整数";
            case "32":
                return "一位数除三位数，结果为整数";
            case "33":
                return "两位数乘一位数";
            case "34":
                return "两位数相乘";
            case "35":
                return "含小数的加减法";
            case "41":
                return "含括号的三运算符";
            case "42":
                return "含小数的加，减法";
            case "51":
                return "除数是整数,算式可除的小数除法";
            case "52":
                return "小数乘，除法";
            case "53":
                return "同分母的分数加，减法";
            case "54":
                return "异分母的加，减法";
            case "55":
                return "含分母的加减混合运算";
            case "61":
                return "分数乘整数";
            case "62":
                return "分数乘分数";
            case "63":
                return "含括号的三运算符";
            default:
        }
        return "未知类型";
    }

    public String getMostType(){
        SQLDao sqlDao=new SQLDao(context);
        return getType(sqlDao.getworstType());
    }

    public List<ExpressionWrapper> parseRecordFile(int code){
        FileDao fileDao=new FileDao();
        String text=fileDao.getText("h"+code);
        Scanner scan=new Scanner(text);
        List<ExpressionWrapper> lists=new ArrayList<>();
        while(scan.hasNextLine()){
            lists.add(new ExpressionWrapper(scan.nextLine()));
        }
        return lists;
    }
}
