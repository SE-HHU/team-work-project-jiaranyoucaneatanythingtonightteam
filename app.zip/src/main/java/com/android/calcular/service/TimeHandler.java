package com.android.calcular.service;


import android.os.Handler;
import android.os.Message;

import com.android.calcular.ui.PracticePageFragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.LogRecord;

/**
 * project name: Calcular
 * Date 2021/10/26 17:34
 *
 * @PackageName: com.android.calcular.service
 * @ClassName: TimeHandler
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class TimeHandler extends Handler {
    Date date2;
    int time;

    public TimeHandler(){
        date2=new Date();
        time=0;
    }
    public void setDate2(){
        date2=new Date();
    }

    public int getTime(){
        return time;
    }
    @Override
    public void handleMessage(Message msg)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date=new Date();
        int secondNum=(int)(((date.getTime()-date2.getTime())/(1000))%60);
        int minNum = (int)(((date.getTime()-date2.getTime())/(60*1000))%60);
        int hourNum = (int)(((date.getTime()-date2.getTime())/(60*60*1000))%24);
        int dayNum=(int)((date.getTime()-date2.getTime())/(24*60*60*1000));
        PracticePageFragment.textViewTimer.setText(hourNum+":"+minNum+":"+secondNum);
        time=(int)((date.getTime()-date2.getTime())/(1000));
    }

}
