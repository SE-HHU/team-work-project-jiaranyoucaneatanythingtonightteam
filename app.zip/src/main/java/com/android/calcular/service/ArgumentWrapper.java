package com.android.calcular.service;

/**
 *Date 2021/9/28 22:31
 *@Author: Likailing
 *@Version: 1.0
 *@Desciption: 输入参数的包装类
 */
public class ArgumentWrapper {
    /**
     * 题目数量
     */
    int amount;
    /**
     * 运算符个数
     */
    int opr_number;
    /**
     * 运算符类型 1加 2减 3乘 4除  如只含加减，表示为120
     */
    int[][] flag=null;
    /**
     * 定义四个数字类型 0整数 1小数 2分数(21表示同分母，22表示异分母)
     */
    int[] no_type =null;
    /**
     * 定义四个数的上下界，如果第三个数，用不上，则他的范围是0
     */
    int[] lower_bound=null;
    int[] upper_bound=null;
    /**
     * 结果是否为整数  true表示为整数，false表示不要求结果一定为整数
     */
    Boolean result;
    /**
     * 是否有括号
     */
    boolean bracket;

    int identifyCode;

    boolean shouldCheck;
    public ArgumentWrapper(boolean shouldCheck, int code, int amount, int opr_number, int[][] flag, int[] no_type, int[] lower_bound, int[] upper_bound, Boolean result, boolean bracket) {
        this.amount = amount;
        this.opr_number = opr_number;
        this.flag = flag;
        this.no_type = no_type;
        this.lower_bound = lower_bound;
        this.upper_bound = upper_bound;
        this.result = result;
        this.bracket = bracket;
        this.shouldCheck=shouldCheck;
        this.identifyCode=code;
    }

    public ArgumentWrapper(boolean shouldCheck, int amount, int opr_number, int[][] flag, int[] no_type, int[] lower_bound, int[] upper_bound, Boolean result, boolean bracket) {
        this.amount = amount;
        this.opr_number = opr_number;
        this.flag = flag;
        this.no_type = no_type;
        this.lower_bound = lower_bound;
        this.upper_bound = upper_bound;
        this.result = result;
        this.bracket = bracket;
        this.shouldCheck=shouldCheck;
    }


    public ArgumentWrapper(int amount, int opr_number, int[][] flag, int[] no_type, int[] lower_bound, int[] upper_bound, Boolean result, boolean bracket) {
        this.amount = amount;
        this.opr_number = opr_number;
        this.flag = flag;
        this.no_type = no_type;
        this.lower_bound = lower_bound;
        this.upper_bound = upper_bound;
        this.result = result;
        this.bracket = bracket;
        this.shouldCheck=true;
    }

    public ArgumentWrapper(int code, int amount, int opr_number, int[][] flag, int[] no_type, int[] lower_bound, int[] upper_bound, Boolean result, boolean bracket) {
        this.amount = amount;
        this.opr_number = opr_number;
        this.flag = flag;
        this.no_type = no_type;
        this.lower_bound = lower_bound;
        this.upper_bound = upper_bound;
        this.result = result;
        this.bracket = bracket;
        this.identifyCode=code;
    }

    public void setAmount(int amount){
        this.amount=amount;
    }
    public void setIdentifyCode(int code){
        this.identifyCode=code;
    }

    public int getIdentifyCode() {
        return identifyCode;
    }
}
