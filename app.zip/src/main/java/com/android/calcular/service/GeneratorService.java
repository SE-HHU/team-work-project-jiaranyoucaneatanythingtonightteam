package com.android.calcular.service;

import com.android.calcular.preference.Arguments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
/**
 *Date 2021/9/28 22:35
 *@Author: Likailing
 *@Version: 1.0
 *@Desciption: 用于生成题目的服务类
 */
public class GeneratorService {
    /**
     * 生成的题目集合
     */
    public List<ExpressionWrapper> expList=new ArrayList<ExpressionWrapper>();
    /**
     * 随机数生成器
     */
    private Random random=new Random();
    /**
     * 参数对象
     */
    private ArgumentWrapper arg;
    private    ArgumentWrapper[] arg1;
    /**
     * 运算符数量
     */
    private int value=0;
    /**
     * 括号数量
     */
    private static int brackets=0;
    /**
     * 运算符的数量上限
     */
    static final int VALUE_LIMIT =3;
    /**
     * 括号的数量上限
     */
    static final int BRACKET_LIMIT =2;


    public  void  generate(int grade) {
        ArgumentWrapper[] arg1= Arguments.getRandomArgument(grade);
        expList.clear();
        this.arg1 = arg1;
        int Timu= 0;
        int count = 0;
        int number = 0;//运算符变量二维数组第二行的总和
        int row = 0;//运算符变量二维数组的行数
        int len=0;//实际生成类型题目数量
        int t=0;//参数
        int ran=0;//储存随机的类型
        // * 求运算符变量的数组行数
        while(arg1[t]!=null){
            len++;
            t++;
        }
        while (Timu<20) {
            number=0;
            row =0;
            ran = (int)(Math.random()*len);
            arg = arg1[ran];
            for (int j = 0; j < 3; j++) {
                number += arg1[ran].flag[1][j];
            }
            if (number > 0) {
                row = 1;
            }
            /*
             * 生成指定数量的题目
             */
            count =0;
            System.out.println(ran);
            while (count < 1) {
                int Random_row = random.nextInt( row+1);//在存在的运算符二维数组行内随机选取，如果只有一行，就一直循环随机的结果是0
                List units = new ArrayList();
                if (arg1[ran].bracket) {
                    brackets = 0;
                    value = 0;
                    do {
                        //TODO
                        if (random.nextBoolean() || value >= 2) {
                            generateNormal(units, arg1[ran].no_type[value], arg1[ran].lower_bound[value], arg1[ran].upper_bound[value]);
                            if (units.get(units.size() - 1).equals(Value.DIVIDE)) {

                            }
                        } else {
                            units.add(Value.BRACKET_LEFT);
                            generateSonExp(units);
                            units.add(Value.BRACKET_RIGHT);
                        }
//                    boolean condition1=random.nextBoolean()||value<2;
                        if (value < 3) {
                            generateValue(units, arg1[ran].flag[Random_row]);
                            value++;
                        } else {
                            break;
                        }
                    } while (value <= 3);
                } else {
                    value = 0;
                    do {
                        generateNormal(units, arg1[ran].no_type[value], arg1[ran].lower_bound[value], arg1[ran].upper_bound[value]);
                        boolean condition2 = value < arg1[ran].opr_number;
                        if (condition2) {
                            generateValue(units,arg1[ran].flag[Random_row]);
                            value++;
                        } else {
                            break;
                        }

                    } while (value <= arg1[ran].opr_number);

                }
                ExpressionWrapper expressionWrapper = new ExpressionWrapper(units);


                if (expressionWrapper.valid && (!expList.contains(expressionWrapper) || !arg1[ran].shouldCheck) && expressionWrapper.result.compareTo(new FractionWrapper(0)) >= 0) {
                    if (expressionWrapper.result.mother != 1 && arg1[ran].result
                            || (arg1[ran].no_type[0] == 1 && arg1[ran].no_type[1] == 0 && (double) expressionWrapper.result.son * 100 / expressionWrapper.result.mother != expressionWrapper.result.son * 100 / expressionWrapper.result.mother)) {
                        continue;
                    }
//                大概不用该判断语句
                    expressionWrapper = removeNeedlessBracket(expressionWrapper);
                    expressionWrapper = removeRepeatBracket(expressionWrapper);
                    expList.add(expressionWrapper);
                    count++;

                }

            }
            Timu++;
        }
    }


    /**
     * @author 12042
     * @Desciption 产生指定参数控制的题目集
     * @Date 16:02 2021/9/25
     * @Param [arg]
     * @return void
     **/
    public void generate(ArgumentWrapper arg){
        expList.clear();
        this.arg=arg;
        int count=0;
        int number=0;//运算符变量二维数组第二行的总和
        int row = 0;//运算符变量二维数组的行数
        // * 求运算符变量的数组行数
        for (int j=0;j<3;j++){
            number+=arg.flag[1][j];
        }
        if(number>0) {
            row=1;
        }
        /*
         * 生成指定数量的题目
         */
        while(count<arg.amount){
            int Random_row =random.nextInt(row+1);//在存在的运算符二维数组行内随机选取，如果只有一行，就一直循环随机的结果是1
            List units=new ArrayList();
            if(arg.bracket){
                brackets=0;
                value=0;
                do{
                    //TODO
                    if(random.nextBoolean()||value>=2){
                        generateNormal(units,arg.no_type[value],arg.lower_bound[value],arg.upper_bound[value]);
                        if(units.get(units.size()-1).equals(Value.DIVIDE)){

                        }
                    }else{
                        units.add(Value.BRACKET_LEFT);
                        generateSonExp(units);
                        units.add(Value.BRACKET_RIGHT);
                    }
//                    boolean condition1=random.nextBoolean()||value<2;
                    if(value<3) {
                        generateValue(units,arg.flag[Random_row]);
                        value++;
                    }else{
                        break;
                    }
                }while(value<=3);
            }else{
                value=0;
                do{
                    generateNormal(units,arg.no_type[value],arg.lower_bound[value],arg.upper_bound[value]);
                    boolean condition2= value < arg.opr_number;
                    if(condition2) {
                        generateValue(units,arg.flag[Random_row]);
                        value++;
                    }else{
                        break;
                    }

                }while(value<=arg.opr_number);

            }
            ExpressionWrapper expressionWrapper =new ExpressionWrapper(units);


            if(expressionWrapper.valid&&(!expList.contains(expressionWrapper)||!arg.shouldCheck)&& expressionWrapper.result.compareTo(new FractionWrapper(0))>=0){
                if(expressionWrapper.result.mother!=1&&arg.result
                        || (arg.no_type[0]==1&&arg.no_type[1]==0&&(double)expressionWrapper.result.son*100/expressionWrapper.result.mother!=expressionWrapper.result.son*100/expressionWrapper.result.mother)){
                    continue;
                }
//                大概不用该判断语句
                expressionWrapper =removeNeedlessBracket(expressionWrapper);
                expressionWrapper=removeRepeatBracket(expressionWrapper);
                expList.add(expressionWrapper);
                count++;
            }

        }

    }


    /**
     *@Params: [expressionWrapper]
     *@Return: com.android.arithmeticexcercise.ExpressionWrapper
     *@Author: Likailing
     *@Date: 2021/9/28 22:57
     *@Desciption: 去除两端不合理的括号
     */
    private ExpressionWrapper removeNeedlessBracket(ExpressionWrapper expressionWrapper){
        if(expressionWrapper.orinalUnits.get(0).equals(Value.BRACKET_LEFT)&& expressionWrapper.orinalUnits.get(expressionWrapper.orinalUnits.size()-1).equals(Value.BRACKET_RIGHT)){
            expressionWrapper.orinalUnits.remove(expressionWrapper.orinalUnits.size()-1);
            expressionWrapper.orinalUnits.remove(0);
            List newUnits= expressionWrapper.orinalUnits;
            return new ExpressionWrapper(newUnits);
        }
        return expressionWrapper;
    }
    /**
     *@Params: [expressionWrapper]
     *@Return: com.android.arithmeticexcercise.ExpressionWrapper
     *@Author: Likailing
     *@Date: 2021/9/28 22:57
     *@Desciption: 去除重复的不合理的括号
     */
    private ExpressionWrapper removeRepeatBracket(ExpressionWrapper expressionWrapper){
        int removeLeft = -1;
        int removeRight = -1;
        for(int i=0;i<expressionWrapper.orinalUnits.size();i++){
            if(expressionWrapper.orinalUnits.get(i).equals(Value.BRACKET_LEFT)){
                if(expressionWrapper.orinalUnits.get(i+1).equals(Value.BRACKET_LEFT)){
                    removeLeft =i+1;
                }
            }
            if (expressionWrapper.orinalUnits.get(i).equals(Value.BRACKET_RIGHT)){
                if(expressionWrapper.orinalUnits.get(i+1).equals(Value.BRACKET_RIGHT)){
                    removeRight = i;
                }
            }
        }
        if(removeLeft>=0&&removeRight>0){
            expressionWrapper.orinalUnits.remove(expressionWrapper.orinalUnits.get(removeLeft));
            expressionWrapper.orinalUnits.remove(expressionWrapper.orinalUnits.get(removeRight));
            List newUnits= expressionWrapper.orinalUnits;
            return new ExpressionWrapper(newUnits);
        }
        return expressionWrapper;
    }

    /**
     * @author 12042
     * @Desciption 生成题目中的括号表达式
     * @Date 17:36 2021/9/24
     * @Param [len]表达式长度
     * @return com.teachertom.appTest.Expression
     **/

    private void generateSonExp(List units){
        brackets++;
        int valueIn=0;
        do{
            //TODO
            if(value== VALUE_LIMIT ||brackets>= BRACKET_LIMIT){
                generateNormal(units,arg.no_type[value],arg.lower_bound[value],arg.upper_bound[value]);
            }else {
                units.add(Value.BRACKET_LEFT);
                generateSonExp(units);
                units.add(Value.BRACKET_RIGHT);
            }
            boolean condition=random.nextBoolean()||valueIn<1;
            if(condition&&value< VALUE_LIMIT -1) {
                generateValue(units,arg.flag[0]);
                value++;
                valueIn++;
            }else{
                break;
            }
        }while(value< VALUE_LIMIT);


    }
    /**
     * @author 12042
     * @Desciption 生成题目中的单一数字
     * @Date 17:41 2021/9/24
     * @Param [units]
     * @return void
     **/
    private void generateNormal(List units,int no_type,int lower_bound,int upper_bound){


        if (no_type == 0&&upper_bound!=0) {
            int i =random.nextInt(upper_bound-lower_bound)+lower_bound;
            while (i==0) {
                i =random.nextInt(upper_bound-lower_bound)+lower_bound;
            }
            units.add(new FractionWrapper(i));

        }
        if (no_type == 1) {
            int i = (int) (random.nextDouble()*(double) upper_bound* 10);
            while(i==0) {
                i = (int) (random.nextDouble()*(double) upper_bound* 10);
            }
//            double d2 = (double) i / 10;
            FractionWrapper fractionWrapper=new FractionWrapper(i,10);
            fractionWrapper.setDecimal();
            units.add(fractionWrapper);
        }
        if (no_type == 20) {
            int mother=random.nextInt(20) + 2;
            FractionWrapper fractionWrapper = new FractionWrapper(random.nextInt(mother-1)+1, mother);
            units.add(fractionWrapper);
        }
        if (no_type == 21) {//异分母
            FractionWrapper fractionWrapper =null;
            if(units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper){
                do {
                    int mother=random.nextInt(20)+1;
                    fractionWrapper = new CalculatorService().simplifyFraction(new FractionWrapper(random.nextInt(mother)+1, mother));
                }while(fractionWrapper.compareMother(units.get(units.size()-2))==0);
            }
            else{
                int mother=random.nextInt(20)+1;
                fractionWrapper = new CalculatorService().simplifyFraction(new FractionWrapper(random.nextInt(mother)+1, mother));
            }
            units.add(fractionWrapper);
        }
        if (no_type == 22) {//同分母
            FractionWrapper fractionWrapper =null;
            if(units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper){
                do {
                    int mother=random.nextInt(20)+1;
                    fractionWrapper = new CalculatorService().simplifyFraction(new FractionWrapper(random.nextInt(mother)+1, mother));
                }while(fractionWrapper.compareMother(units.get(units.size()-2))==1);
            }
            else{
                int mother=random.nextInt(20)+1;
                fractionWrapper = new CalculatorService().simplifyFraction(new FractionWrapper(random.nextInt(mother)+1, mother));
            }
            units.add(fractionWrapper);
        }
    }
    private int value1=0;
    /**
     * @author 12042
     * @Desciption 产生运算符
     * @Date 09点56分 2021/10/24
     * @Param []
     * @return void
     **/
    private void generateValue(List units,int[] flag){
        int add=flag[0];
        int minus=flag[1];
        int multiply=flag[2];
        int divide=flag[3];
        int r =0;//存储随机的数

        do{
            r=random.nextInt(4)+1;
        }while(!( r==add|| r==minus|| r==multiply|| r==divide)||(arg.identifyCode==23||arg.identifyCode==25)&&r==value1);
//      如果r 等于以上四个中的如何一个，则退出循环
        if(units.size()<=1){
            value1=r;
        }
        switch (r){
            case 1:
                units.add(Value.ADD);
                break;
            case 2:
                units.add(Value.MINUS);
                break;
            case 3:
                units.add(Value.MULTIPLY);
                break;
            case 4:
                units.add(Value.DIVIDE);
                break;
            default:
                break;
        }

    }
    private void generateValue(List units,int[] flag,ArgumentWrapper arg1){
        int add=flag[0];
        int minus=flag[1];
        int multiply=flag[2];
        int divide=flag[3];
        int r =0;//存储随机的数

        do{
            r=random.nextInt(4)+1;
        }while(!( r==add|| r==minus|| r==multiply|| r==divide)||(arg1.identifyCode==23||arg1.identifyCode==25)&&r==value1);
//      如果r 等于以上四个中的如何一个，则退出循环
        if(units.size()<=1){
            value1=r;
        }
        switch (r){
            case 1:
                units.add(Value.ADD);
                break;
            case 2:
                units.add(Value.MINUS);
                break;
            case 3:
                units.add(Value.MULTIPLY);
                break;
            case 4:
                units.add(Value.DIVIDE);
                break;
            default:
                break;
        }

    }
    /**
     *@Params: []
     *@Return: java.util.List<com.android.arithmeticexcercise.ExpressionWrapper>
     *@Author: Likailing
     *@Date: 2021/9/28 22:57
     *@Desciption: 获取生成的题目集合
     */
    public List<ExpressionWrapper> getList(){
        return expList;
    }
}

