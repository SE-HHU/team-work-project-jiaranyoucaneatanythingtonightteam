package com.android.calcular.service;
/**
  *Date 2021/9/28 22:40
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 符号枚举类
  */
public enum Value {
    /**
     * 左括号
     */
    BRACKET_LEFT,
    /**
     * 右括号
     */
    BRACKET_RIGHT,
    /**
     * 加号
     */
    ADD,
    /**
     * 减号
     */
    MINUS,
    /**
     * 乘号
     */
    MULTIPLY,
    /**
     * 除号
     */
    DIVIDE,
    /**
     * 分数线
     */
    DIVIDE_FRA,
    /**
     * 等号
     */
    EQUAL;
}
