package com.android.calcular;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;

import com.android.calcular.adapter.ViewPageAdapter;
import com.android.calcular.control.PracticeAction;
import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;
import com.android.calcular.data.SQLHelper;
import com.android.calcular.ui.HomeFragment;
import com.android.calcular.ui.MineFragment;
import com.android.calcular.ui.PracticeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    public static Context myContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myContext=this;
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        this.setTitle("首页");
        SQLDao sqlDao=new SQLDao(this);
        if(sqlDao.getAllStuInfo().size()==0&&sqlDao.getAllStudyRecords().size()==0){
            Intent intent=new Intent(this,GuideActivity.class);
            startActivity(intent);
        }

        ViewPager2 viewPager2=findViewById(R.id.viewpager);
        BottomNavigationView btmView=findViewById(R.id.nav_view);
        List<Fragment> fragmentList=new ArrayList<Fragment>();
        fragmentList.add(new HomeFragment());
        fragmentList.add(new PracticeFragment());
        fragmentList.add(new MineFragment());
        viewPager2.setAdapter(ViewPageAdapter.start(this,fragmentList));
        viewPager2.setOffscreenPageLimit(1);
        btmView.setOnNavigationItemSelectedListener((MenuItem item)->{
            switch(item.getItemId()){
                case R.id.navigation_home:
                    viewPager2.setCurrentItem(0);

                    break;
                case R.id.navigation_practice:
                    viewPager2.setCurrentItem(1);

                    break;
                case R.id.navigation_mine:
                    viewPager2.setCurrentItem(2);
                    ((MineFragment)fragmentList.get(2)).refresh();
                    break;
                default:
            }
            return false;
        });
        Activity activity=this;
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position){
                    case 0:
                        activity.setTitle("首页");
                        break;
                    case 1:
                        activity.setTitle("同步练习");
                        break;
                    case 2:
                        activity.setTitle("我的");
                        break;
                    default:
                }
                btmView.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }
        }
        );
        FileDao.folderPath =this.getExternalFilesDir(null).getPath();
        sqlDao.getAllStuInfo();
        sqlDao.getAllStudyRecords();
        PracticeAction practiceAction=new PracticeAction(this);
        practiceAction.setMineData();
    }

}