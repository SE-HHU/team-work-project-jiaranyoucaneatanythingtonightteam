package com.android.calcular;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.android.calcular.control.PracticeAction;
import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.ui.PracticePageFragment;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.calcular.databinding.ActivityWrongbookBinding;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class WrongbookActivity extends AppCompatActivity {

    private ActivityWrongbookBinding binding;
    private static List<ExpressionWrapper> expressionWrapperList=new ArrayList<>();

    public static void setList(List<ExpressionWrapper> expList){
        expressionWrapperList=expList;
    }
    private final int LENGTH_QUESTION=12;
    private final int LENGTH_RESULT=20;
    /**
    *@Params: []
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/11/6 19:42
    *@Desciption: 返回错误题目信息文本
    */
    private String getWrongText(){
        StringBuilder line=new StringBuilder();
        StringBuilder text=new StringBuilder();
        Iterator<ExpressionWrapper> iterator=expressionWrapperList.iterator();
        while(iterator.hasNext()){
            line=new StringBuilder();
            ExpressionWrapper next=iterator.next();
            String answer=""+next.getInputAnswer();
            if(answer.equals("null")){
                answer="未完成";
            }
            line.append(next.getQuest()+"\n");
            text.append(line);
            line=new StringBuilder();
            line.append("|正解："+next.result);
            while(line.length()<LENGTH_RESULT){
                line.append(" ");
            }
            line.append("|错解:"+answer+"\n");
            text.append(line);
        }
        return text.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context thisContext=this;
        binding = ActivityWrongbookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.setTitle("错题本");
        TextView textViewWrongBook=findViewById(R.id.textView_wrongbook);
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);

        CollapsingToolbarLayout toolBarLayout = binding.toolbarLayout;
        toolBarLayout.setTitle(getTitle());
        getSupportActionBar().setTitle("错题本");
        FloatingActionButton fab = binding.fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "点击随机练习我的错题", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                PracticePageFragment.initialData();
                List<ExpressionWrapper> randomList=new ArrayList<>();
                Random random=new Random();
                while(randomList.size()<20&&expressionWrapperList.size()>20){
                   int index=random.nextInt(expressionWrapperList.size());
                   if(!randomList.contains(expressionWrapperList.get(index))){
                       randomList.add(expressionWrapperList.get(index));
                   }

                }
                Intent intent=new Intent(thisContext,PracticeActivity.class);
                if(expressionWrapperList.size()>20){
                    PracticePageFragment.setExpList(randomList);
                    startActivity(intent);
                }else if(expressionWrapperList.size()>0){
                    PracticePageFragment.setExpList(expressionWrapperList);
                    startActivity(intent);
                }else{
                    Toast.makeText(thisContext,"你没有可以练习的错题哦！",Toast.LENGTH_SHORT);
                }




            }
        });
        textViewWrongBook.setText(getWrongText());
    }


}