package com.android.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.service.InfoAccessService;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class WeeklyReportActivity extends AppCompatActivity {
    private LineChart lineChart;
    private static List<Integer> tcounts;
    private static List<Float> taccuracies;
    private static List<ExpressionWrapper> wrongs;
    private static Set<Map.Entry<String,Integer>> entrySet;
    private static int thisCount;
    private static int lastCount;
    private static float thisAccuracy;
    private static float lastAccuracy;
    private  static String mostType;
    TextView textViewWrongConclusion;
    /**
    *@Params: [counts, accuracies]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/11/11 21:27
    *@Desciption:获取一周内的做题数据
    */
    public static void setWeeklyDatas(List<Integer> counts,List<Float> accuracies,List<ExpressionWrapper> wrongsList,Set<Map.Entry<String,Integer>> entrys,int tCount,int lCount,float tAccuracy,float lAccuracy,String mType){
        tcounts=counts;
        taccuracies=accuracies;
        wrongs=wrongsList;
        thisCount=tCount;
        lastCount=lCount;
        thisAccuracy=tAccuracy;
        lastAccuracy=lAccuracy;
        mostType=mType;
        entrySet=entrys;
    }
    /**
    *@Params: []
    *@Return: java.util.List<com.github.mikephil.charting.data.Entry>
    *@Author: Likailing
    *@Date: 2021/11/11 21:29
    *@Desciption:将数据包装为Entry集合
    */
    private List<Entry> loadCountsToEntry(){
        Iterator<Integer> iterator=tcounts.iterator();
        List<Entry> list=new ArrayList<>();
        int index=0;
        while(iterator.hasNext()){
            list.add(new Entry(iterator.next(),index++));
        }
        return list;
    }

    private List<Entry> loadAccuraciesToEntry(){
        Iterator<Float> iterator=taccuracies.iterator();
        List<Entry> list=new ArrayList<>();
        int index=0;
        while(iterator.hasNext()){
            list.add(new Entry(iterator.next(),index++));
        }
        return list;
    }

    private void setWrongs(){
        StringBuilder text=new StringBuilder();
        Iterator<ExpressionWrapper> iterator=wrongs.iterator();
        while(iterator.hasNext()){
            ExpressionWrapper next=iterator.next();
            if(!next.isCorrect()){
                text.append(next.getQuest()+"\n");
            }
        }
        textViewWrongConclusion.setText(text.toString());
    }

    private void setWrongTypes(){
        StringBuilder text=new StringBuilder();
        InfoAccessService infoAccessService=new InfoAccessService(this);
        Iterator<Map.Entry<String,Integer>> iterator=entrySet.iterator();
        while(iterator.hasNext()){
            Map.Entry<String,Integer> entry=iterator.next();
            text.append("类型:"+infoAccessService.getType(entry.getKey())+"\n");
            text.append("做错了"+entry.getValue()+"题\n");
        }
        textViewWrongConclusion.setText(text.toString());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly_report);
        this.setTitle("学习周报");
        lineChart=findViewById(R.id.lineChart);
        TextView textViewTotalAmount=findViewById(R.id.textView_totalAmount);
        TextView textViewChangedAmount=findViewById(R.id.textView_amountChange);
        TextView textViewAverageAccuracy=findViewById(R.id.textView_averageAccuracy);
        TextView textViewChangedAccuracy=findViewById(R.id.textView_accuracyChange);
        TextView textViewMostType=findViewById(R.id.textView_mostWrongType);
        textViewWrongConclusion=findViewById(R.id.textView_wrongConclusion);
        textViewTotalAmount.setText(""+thisCount+"题");
        textViewChangedAmount.setText(""+(thisCount-lastCount)+"题");
        textViewAverageAccuracy.setText(""+(int)(thisAccuracy*100+0.5)+"%");
        textViewChangedAccuracy.setText(""+(int)(thisAccuracy*100-lastAccuracy*100+0.5)+"%");
        textViewMostType.setText(mostType);
        setWrongTypes();
        lineChart.setDescription("本周");
        lineChart.setNoDataTextDescription("本周你还没有进行练习哦!");
        lineChart.setDrawGridBackground(false);

        LineDataSet cSet=new LineDataSet(loadCountsToEntry(),"做题数量");
        LineDataSet aSet=new LineDataSet(loadAccuraciesToEntry(),"正确率");
        cSet.setValueTextSize(8f);
        aSet.setValueTextSize(8f);
        cSet.setDrawFilled(true);
        aSet.setDrawFilled(true);
        cSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        cSet.setFillColor(Color.GREEN);
        cSet.setColor(Color.GREEN);
        aSet.setAxisDependency(YAxis.AxisDependency.RIGHT);
        ArrayList<LineDataSet> dataSets = new ArrayList<LineDataSet>();
        dataSets.add(cSet);
        dataSets.add(aSet);
        ArrayList<String> xVals = new ArrayList<String>();
        xVals.add("周一"); xVals.add("周二"); xVals.add("周三"); xVals.add("周四");xVals.add("周五");xVals.add("周六");xVals.add("周日");
        LineData data = new LineData(xVals, dataSets);
        lineChart.setData(data);
        lineChart.invalidate();
        AxisBase xAxis=lineChart.getXAxis();
        xAxis.setEnabled(true);
        xAxis.setDrawGridLines(false);
        YAxis yAxis=lineChart.getAxisRight();
        yAxis.setAxisMaxValue(1.0f);
        // 设置动画
        lineChart.animateY(2000, Easing.EasingOption.EaseInElastic ); // 图4
    }
}