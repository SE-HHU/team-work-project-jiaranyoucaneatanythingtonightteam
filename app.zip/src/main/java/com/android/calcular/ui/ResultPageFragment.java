package com.android.calcular.ui;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.calcular.R;
import com.android.calcular.service.ExpressionWrapper;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ResultPageFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ResultPageFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private static int score;
    private static int time;
    private static String wrongs;
    private static TextView textViewScore;
    private  static TextView textViewTime;
    private static TextView textViewWrongs;
    private Button buttonReturn;
    private static ScrollView scrollView;
    View view;
    static Drawable d1;
    static Drawable d2;
    public ResultPageFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ResultPageFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ResultPageFragment newInstance(String param1, String param2) {
        ResultPageFragment fragment = new ResultPageFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_result_page,null);
        textViewScore=view.findViewById(R.id.textView_score);
        textViewTime=view.findViewById(R.id.textView_usetime);
        textViewWrongs=view.findViewById(R.id.textView_wrongs);
        buttonReturn=view.findViewById(R.id.button_return);
        scrollView=view.findViewById(R.id.scrollView_result);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        buttonReturn.setOnClickListener((View v)->{
            getActivity().finish();
        });
        d1=getResources().getDrawable(R.drawable.result_2);
        d2=getResources().getDrawable(R.mipmap.backing_result);



    }


    public static void setInfos(int score, int time, String wrongs){
        textViewScore.setText(String.valueOf(score));
        textViewTime.setText(getFormatTime(time));
        textViewWrongs.setText(String.valueOf(wrongs));
        if(score<80){
            scrollView.setBackground(d1);
        }else{
            scrollView.setBackground(d2);
        }
    }

    private static String getFormatTime(int time){
        StringBuilder stringBuilder=new StringBuilder();
        int second=time%60;
        int min=(time/60)%60;
        int hour=((time/60)/60)%24;
        stringBuilder.append("用时："+hour+"时");
        stringBuilder.append(min+"分");
        stringBuilder.append(second+"秒");
        return stringBuilder.toString();
    }


}