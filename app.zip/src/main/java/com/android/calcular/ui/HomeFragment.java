package com.android.calcular.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.calcular.PracticeActivity;
import com.android.calcular.R;
import com.android.calcular.RecommendActivity;
import com.android.calcular.RecordActivity;
import com.android.calcular.WeeklyReportActivity;
import com.android.calcular.WrongbookActivity;
import com.android.calcular.control.PracticeAction;
import com.android.calcular.preference.Arguments;
import com.android.calcular.service.ArgumentWrapper;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    View view;
    ImageButton imageButtonQuick;
    CardView cardViewWrongs;
    CardView cardViewReport;
    CardView cardViewRecords;
    CardView cardViewRecommend;
    CardView cardViewLast;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_home, container, false);
        imageButtonQuick=view.findViewById(R.id.imageButton_quickExcercise);
        cardViewWrongs=view.findViewById(R.id.cardView_wrongs);
        cardViewReport=view.findViewById(R.id.cardView_weeklyReport);
        cardViewRecords=view.findViewById(R.id.cardView_records);
        cardViewRecommend=view.findViewById(R.id.cardView_recommend);
        cardViewLast=view.findViewById(R.id.cardView_lastRecord);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        imageButtonQuick.setOnClickListener((View v)->{
            ArgumentWrapper argument=Arguments.getRandomArgument();
            argument.setAmount(20);
            PracticeFragment.oralType=String.valueOf(argument.getIdentifyCode());
            PracticeAction practiceAction=new PracticeAction(this.getContext());
            practiceAction.startGenerating(argument);
            PracticePageFragment.initialData();
            Intent intent=new Intent(this.getContext(), PracticeActivity.class);
            startActivity(intent);
            Log.i("practice",argument.getIdentifyCode()+"");
        });

        cardViewWrongs.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(getContext());
            practiceAction.startWrongBook();
            Intent intent=new Intent(this.getContext(), WrongbookActivity.class);
            startActivity(intent);
        });

        cardViewReport.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this.getContext());
            practiceAction.setWeeklyData();
            Intent intent=new Intent(this.getContext(), WeeklyReportActivity.class);
            startActivity(intent);
        });

        cardViewRecords.setOnClickListener((View v)->{
            Intent intent=new Intent(this.getContext(), RecordActivity.class);
            startActivity(intent);
        });

        cardViewRecommend.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(getContext());
            practiceAction.setRecommendData();
            Intent intent=new Intent(this.getContext(), RecommendActivity.class);
            startActivity(intent);
        });
        cardViewLast.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(getContext());
            PracticePageFragment.initialData();
            if(practiceAction.startLastPractice()){
                Intent intent=new Intent(this.getContext(), PracticeActivity.class);
                startActivity(intent);
            }else{
                Toast.makeText(getContext(),"您还没有做过练习哦~",Toast.LENGTH_SHORT).show();
            }


        });
    }
}