package com.android.calcular.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.calcular.PracticeActivity;
import com.android.calcular.R;
import com.android.calcular.control.PracticeAction;
import com.android.calcular.service.CalculatorService;
import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.service.FractionWrapper;
import com.android.calcular.service.InfoAccessService;
import com.android.calcular.service.TimeHandler;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PracticePageFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PracticePageFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static List<ExpressionWrapper> expList;
    private static List<FractionWrapper> answersList = new ArrayList<>();
    private static int num = 1;
    public static TimeHandler timerHandler;    //定义一个TimerHandler全局变量
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    View view;
    public static TextView textViewTimer;
    private TextView textViewNum;
    private TextView textViewQuestion;
    private TextView textViewFractionLine;
    private EditText editTextInteger;
    private EditText editTextFractionMother;
    private EditText editTextFractionSon;
    private EditText editTextDecimal;
    Button buttonPrev;
    Button buttonNext;
    Button buttonSubmit;

    public PracticePageFragment() {
        // Required empty public constructor
    }

    public static void initialData() {
        answersList = new ArrayList<>();
        num = 1;
    }

    public static void setExpList(List<ExpressionWrapper> list) {
        expList = list;
    }

    public static void setAnswersList(List<FractionWrapper> list) {
        answersList = list;
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PracticePageFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static PracticePageFragment newInstance(String param1, String param2) {
        PracticePageFragment fragment = new PracticePageFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        timerHandler = new TimeHandler();  //实例化TimerHandler
        timerHandler.setDate2();
        Timer timer = new Timer();     //设置定时器Timer
        timer.schedule(new MyTimerTask(), 0, 1000);  //0表示无延迟，1000表示隔1000ms


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_practice_page, null);
        textViewTimer = view.findViewById(R.id.textView_timer);
        buttonNext = view.findViewById(R.id.button_next);
        buttonPrev = view.findViewById(R.id.button_prev);
        buttonSubmit = view.findViewById(R.id.button_submit);
        textViewNum = view.findViewById(R.id.textView_questionNumber);
        textViewNum.setText(String.valueOf(num) + "/" + expList.size());
        textViewQuestion = view.findViewById(R.id.textView_questionText);
        textViewQuestion.setText(expList.get(num - 1).getQuest());
        textViewFractionLine = view.findViewById(R.id.textView_fractionLine);
        editTextInteger = view.findViewById(R.id.editText_answer_integer);
        editTextFractionMother = view.findViewById(R.id.editText_answer_fractionmother);
        editTextFractionSon = view.findViewById(R.id.editText_answer_fractionson);
        editTextDecimal = view.findViewById(R.id.editText_answer_decimal);
        setEditType(expList.get(num - 1).getAnswerType());




        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        while (answersList.size() < expList.size()) {
            answersList.add(null);
        }

        buttonNext.setOnClickListener((View v) -> {
            if (num < expList.size()) {
                int type = expList.get(num - 1).getAnswerType();
                answersList.set(num - 1, getAnswer(type));
                num++;
                type = expList.get(num - 1).getAnswerType();

                textViewNum.setText(String.valueOf(num) + "/" + expList.size());
                textViewQuestion.setText(expList.get(num - 1).getQuest());
                setEditType(type);
                setAnswer(num-1);

            }


        });

        buttonPrev.setOnClickListener((View v) -> {
            if (num > 1) {

                int type = expList.get(num - 1).getAnswerType();
                answersList.set(num - 1, getAnswer(type));
                num--;
                textViewNum.setText(String.valueOf(num) + "/" + expList.size());
                textViewQuestion.setText(expList.get(num - 1).getQuest());
                setEditType(expList.get(num - 1).getAnswerType());
                setAnswer(num-1);

            }


        });

        buttonSubmit.setOnClickListener((View v) -> {
            InfoAccessService infoAccessService = new InfoAccessService(this.getContext());
            int type = expList.get(num - 1).getAnswerType();
            answersList.set(num - 1, getAnswer(type));
            PracticeActivity.goToResultPage();
            PracticeAction practiceAction = new PracticeAction(this.getContext());
            practiceAction.checkAnswers(expList, answersList, timerHandler.getTime());

        });
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    private void setEditType(int type) {
        switch (type) {
            case 1:
                editTextInteger.setText("");
                editTextInteger.setVisibility(View.VISIBLE);
                editTextDecimal.setVisibility(View.INVISIBLE);
                editTextFractionSon.setVisibility(View.INVISIBLE);
                editTextFractionMother.setVisibility(View.INVISIBLE);
                textViewFractionLine.setVisibility(View.INVISIBLE);
                break;
            case 2:
                editTextFractionMother.setText("");
                editTextFractionSon.setText("");
                editTextInteger.setVisibility(View.INVISIBLE);
                editTextDecimal.setVisibility(View.INVISIBLE);
                editTextFractionSon.setVisibility(View.VISIBLE);
                editTextFractionMother.setVisibility(View.VISIBLE);
                textViewFractionLine.setVisibility(View.VISIBLE);
                break;
            case 3:
                editTextDecimal.setText("");
                editTextInteger.setVisibility(View.INVISIBLE);
                editTextDecimal.setVisibility(View.VISIBLE);
                editTextFractionSon.setVisibility(View.INVISIBLE);
                editTextFractionMother.setVisibility(View.INVISIBLE);
                textViewFractionLine.setVisibility(View.INVISIBLE);
                break;
            default:
        }
    }

    private FractionWrapper getAnswer(int type) {
        switch (type) {
            case 1:
                String ans = editTextInteger.getText().toString();
                if (ans.length() > 0) {
                    return new FractionWrapper(Integer.parseInt(ans));
                } else {
                    return null;
                }
            case 2:
                String mother = editTextFractionMother.getText().toString();
                String son = editTextFractionSon.getText().toString();
                if (mother.length() > 0 && son.length() > 0) {
                    return new FractionWrapper(Integer.parseInt(son), Integer.parseInt(mother));
                } else {
                    return null;
                }

            case 3:
                String decimal = editTextDecimal.getText().toString();
                if (decimal.length() > 0) {
                    double myDecimal = Double.parseDouble(decimal);
                    FractionWrapper answer = new FractionWrapper((int) (myDecimal * 100), 100);
                    CalculatorService calculatorService = new CalculatorService();
                    answer = calculatorService.simplifyFraction(answer);
                    answer.setDecimal();
                    return answer;
                } else {
                    return null;
                }
            default:
        }
        return null;
    }

    private void setAnswer(int pos) {

        FractionWrapper answer = answersList.get(pos);
        if(answer!=null){
            if (answer.mother == 1 || answer.son == 0) {
                editTextInteger.setText(answer.toString());
            } else if (answer.isDecimal) {
                editTextDecimal.setText(answer.toString());
            }else{
                editTextFractionSon.setText(String.valueOf(answer.son));
                editTextFractionMother.setText(String.valueOf(answer.mother));
            }
        }

    }
}
/**
*@Author: Likailing
*@Date: 2021/10/26 19:18
*@Desciption:计时任务类
*/
class MyTimerTask extends TimerTask
{
    @Override
    public void run()
    {
        PracticePageFragment.timerHandler.sendEmptyMessage(0);
    }
}