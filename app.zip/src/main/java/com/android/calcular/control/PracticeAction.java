package com.android.calcular.control;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.calcular.PracticeActivity;
import com.android.calcular.RecommendActivity;
import com.android.calcular.WeeklyReportActivity;
import com.android.calcular.WrongbookActivity;
import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;
import com.android.calcular.service.ArgumentWrapper;
import com.android.calcular.service.CheckerService;
import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.service.FractionWrapper;
import com.android.calcular.service.GeneratorService;
import com.android.calcular.service.InfoAccessService;
import com.android.calcular.ui.MineFragment;
import com.android.calcular.ui.PracticeFragment;
import com.android.calcular.ui.PracticePageFragment;
import com.android.calcular.ui.ResultPageFragment;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * project name: Calcular
 * Date 2021/10/23 15:32
 *
 * @PackageName: com.android.calcular.control
 * @ClassName: PracticeAction
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class PracticeAction {
    private SQLDao sqlDao;
    Context context;
    public PracticeAction(Context context){

        sqlDao=new SQLDao(context);
        this.context=context;
    }
    /**
    *@Params: [grade]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 15:07
    *@Desciption: 更新年级信息
    */
    public void updateGrade(int grade){
        List last=sqlDao.getNewestStuInfo();
        if(last.size()>0){
            sqlDao.addStuInfo(grade,(double)last.get(1),(int)last.get(2),new Date((long)last.get(3)));
        }else{
            sqlDao.addStuInfo(grade,0,0,new Date());
        }



    }
    /**
    *@Params: [arg]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 15:11
    *@Desciption:开始生成题目
    */
    public void startGenerating(ArgumentWrapper arg){
        GeneratorService generator=new GeneratorService();
        generator.generate(arg);
        Log.i("Generate",generator.getList().toString());
        PracticePageFragment.setExpList(generator.getList());
    }
    public void startGenerating(int grade){
        GeneratorService generator=new GeneratorService();
        generator.generate(grade);
        Log.i("Generate",generator.getList().toString());
        PracticePageFragment.setExpList(generator.getList());
    }

    public void checkAnswers(List<ExpressionWrapper> expList,List<FractionWrapper> answerList,int time){
        CheckerService checkerService=new CheckerService();
        InfoAccessService infoAccessService=new InfoAccessService(context);
        boolean[] results=checkerService.checkAnswer(expList,answerList);
        int score=0;
        int wrongs=0;
        int index=0;
        StringBuilder swrongs=new StringBuilder();
        while(index<results.length){
            if(results[index]){
                score+=100/results.length;
            }else{
                System.out.println(answerList.toString());
                String ans="未填写";
                if(answerList.get(index)!=null){
                    ans=answerList.get(index).toString();
                }
                swrongs.append(expList.get(index).getQuest()+"="+ans+"\n");
                wrongs++;
            }
            index++;
        }
        if(wrongs==0){
            score=100;
        }
        ResultPageFragment.setInfos(score,time,swrongs.toString());
        int code=getRecordCode();
        infoAccessService.saveRecordInfo(code,System.currentTimeMillis(),time,true,score,wrongs, PracticeFragment.oralType,expList.size());
        infoAccessService.printQuestions(code,expList,answerList);
        infoAccessService.saveStudentInfo();
        Log.i("sql","记录已保存");
        Log.i("sql","保存的记录："+sqlDao.getNewestRecord());
        PracticeActivity.goToResultPage();
    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/27 12:46
    *@Desciption:开启打印服务
    */
    public void startPrinter(ArgumentWrapper arg){
        GeneratorService generatorService=new GeneratorService();
        FileDao fileDao=new FileDao();
        InfoAccessService infoAccessService=new InfoAccessService(context);
        generatorService.generate(arg);
        int code=getRecordCode();
        infoAccessService.printQuestions(code,generatorService.getList(),new ArrayList<FractionWrapper>());
        System.out.println("h"+code);
        fileDao.sendToPrinter("h"+code,1);

    }

    public void startPrinter(int grade){
        GeneratorService generatorService=new GeneratorService();
        FileDao fileDao=new FileDao();
        InfoAccessService infoAccessService=new InfoAccessService(context);
        generatorService.generate(grade);
        int code=getRecordCode();
        infoAccessService.printQuestions(code,generatorService.getList(),new ArrayList<FractionWrapper>());
        System.out.println("h"+code);
        fileDao.sendToPrinter("h"+code,1);

    }
    /**
    *@Params: []
    *@Return: int
    *@Author: Likailing
    *@Date: 2021/11/6 15:57
    *@Desciption:获取记录的序列号
    */
    public  int getRecordCode(){
        int code=0;
        Date date=new Date();
        code+= date.getSeconds();
        code+=date.getMinutes()*100;
        code+=date.getHours()*10000;
        code+=date.getDate()*1000000;
        code+=date.getMonth()*10000000;
              return code;

    }
    /**
    *@Params: []
    *@Return: int
    *@Author: Likailing
    *@Date: 2021/11/6 19:09
    *@Desciption:获取上次保存的年级
    */
    public int getGrade(){
        int grade=1;
        SQLDao sqlDao=new SQLDao(context);
        List record=sqlDao.getNewestStuInfo();
        if(record.size()>0){
            grade=(Integer) record.get(0);
        }

        return grade;
    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/11/6 15:58
    *@Desciption:启动错题本,填充数据
    */
    public void startWrongBook(){
        SQLDao sqlDao=new SQLDao(context);
        InfoAccessService infoAccessService=new InfoAccessService(context);
        List<ExpressionWrapper> wrongList=new ArrayList<>();
        List<Integer> codeList=sqlDao.getAllRecordCodes();
        Iterator<Integer> iterator=codeList.iterator();
        while(iterator.hasNext()){
            List<ExpressionWrapper> tempList=infoAccessService.getRecordQuestions(iterator.next());
            Iterator<ExpressionWrapper> tempIterator=tempList.iterator();
            while(tempIterator.hasNext()){
                ExpressionWrapper exp=tempIterator.next();
                if(!exp.isCorrect()){
                    wrongList.add(exp);
                }
            }
        }
        WrongbookActivity.setList(wrongList);
    }

    public List<ExpressionWrapper> getThisWeekWrongs(){
        SQLDao sqlDao=new SQLDao(context);
        InfoAccessService infoAccessService=new InfoAccessService(context);
        List<ExpressionWrapper> wrongList=new ArrayList<>();
        List<Integer> codeList=sqlDao.getThisWeekRecordCodes();
        Iterator<Integer> iterator=codeList.iterator();
        while(iterator.hasNext()){
            List<ExpressionWrapper> tempList=infoAccessService.getRecordQuestions(iterator.next());
            Iterator<ExpressionWrapper> tempIterator=tempList.iterator();
            while(tempIterator.hasNext()){
                ExpressionWrapper exp=tempIterator.next();
                if(!exp.isCorrect()){
                    wrongList.add(exp);
                }
            }
        }
        return wrongList;
    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/11/11 21:38
    *@Desciption: 启动上次练习
    */
    public boolean startLastPractice(){
        InfoAccessService infoAccessService=new InfoAccessService(context);
        SQLDao sqlDao=new SQLDao(context);
        List record=sqlDao.getNewestRecord();
        if(record!=null&&record.size()>0){
            int code=(int)record.get(0);
            List<ExpressionWrapper> list=infoAccessService.parseRecordFile(code);
            List<FractionWrapper> answers=new ArrayList<>();
            Iterator<ExpressionWrapper> iterator=list.iterator();
            while(iterator.hasNext()){
                answers.add(iterator.next().getInputAnswer());
            }
            PracticePageFragment.setExpList(list);
            PracticePageFragment.setAnswersList(answers);
            return true;
        }
        return false;





    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/11/11 21:38
    *@Desciption: 导入周报数据
    */
    public void setWeeklyData(){
        InfoAccessService infoAccessService=new InfoAccessService(context);
        SQLDao sqlDao=new SQLDao(context);
        WeeklyReportActivity.setWeeklyDatas(infoAccessService.getThisWeekCounts(),infoAccessService.getThisWeekAccuracies(),getThisWeekWrongs(),sqlDao.getWrongTypes(),infoAccessService.getThisWeekTotalCount(),infoAccessService.getLastWeekTotalCount(),infoAccessService.getThisWeekTotalAccuracy(),infoAccessService.getLastWeekTotalAccuracy(),infoAccessService.getMostType());
    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/11/14 12:39
    *@Desciption:设置推荐数据
    */
    public void setRecommendData(){
        SQLDao sqlDao=new SQLDao(context);
        InfoAccessService infoAccessService=new InfoAccessService(context);
        Set<Map.Entry<String,Float>> entrySet=sqlDao.getWrongAccuracies();
        List<String> stringList=new ArrayList<>();
        Iterator<Map.Entry<String,Float>> iterator=entrySet.iterator();
        while(iterator.hasNext()&&stringList.size()<3){
            String key=iterator.next().getKey();
            if(!key.equals("00")){
                stringList.add(infoAccessService.getType(key));
            }

        }
        String[] worstTypes = new String[]{"00","11","12","13","14","15","16","17","18","19","21","22","23","24","25","26","31","32","33","34","35","41","42","51","52","53","54","55","61","62","63"};
        while(stringList.size()<3){
            String type=infoAccessService.getType(worstTypes[new Random().nextInt(worstTypes.length-1)+1]);
            if(!stringList.contains(type)){
                stringList.add(type);
            }

        }
        Log.i("type",stringList.toString());
        RecommendActivity.setTypes(stringList);
    }

    public void setMineData(){
        InfoAccessService infoAccessService=new InfoAccessService(context);
        SQLDao sqlDao=new SQLDao(context);
        int count=0;
        List<List> records=sqlDao.getAllStudyRecords();
        Iterator<List> iterator=records.iterator();
        while(iterator.hasNext()){
            count+=(int)iterator.next().get(7);
        }
        if(records.size()==0){
            MineFragment.setDatas(1,0,0,0,0f);
        }else{
            MineFragment.setDatas((int)sqlDao.getNewestStuInfo().get(0),sqlDao.getAllStuInfo().size(),records.size(),count,sqlDao.getAccuracy());
        }

    }
}
