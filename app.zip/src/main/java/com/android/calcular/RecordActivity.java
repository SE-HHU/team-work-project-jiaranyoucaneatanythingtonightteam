package com.android.calcular;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.calcular.control.PracticeAction;
import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;
import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.service.FractionWrapper;
import com.android.calcular.service.InfoAccessService;
import com.android.calcular.ui.PracticePageFragment;

import org.w3c.dom.ls.LSException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;


public class RecordActivity extends AppCompatActivity {

    private List list = new ArrayList();
    private static int LargestCount = 100;
    private ListView recordshow;
    private List<List<ExpressionWrapper>> info=new ArrayList();
    private ArrayAdapter<String> arrayAdapter;
    List<String> data = new ArrayList<>();
    private boolean hasAdd[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        getSupportActionBar().hide();
        SQLDao sqlDao = new SQLDao(this);
        InfoAccessService infoAccessService=new InfoAccessService(this);
        list = sqlDao.getAllStudyRecords();
        Iterator<List> it = list.iterator();
        List date=new ArrayList();
        List timecost=new ArrayList();
        List grade=new ArrayList();
        List wrong=new ArrayList();
        List type=new ArrayList();
        List count=new ArrayList();
        List code=new ArrayList();
        while (it.hasNext()) {
            List info = it.next();
            code.add((int)info.get(0));
            Date tDate=new Date((Long)info.get(1));
            date.add(sqlDao.getBeijingTime(tDate).substring(0,11));
            timecost.add("总耗时（s）:"+info.get(2).toString());
            grade.add("\n成绩："+info.get(4).toString());
            wrong.add("\n错题数量："+info.get(5).toString());
            if(info.get(6).equals("00")){
                info.set(6,"随即练习");
            }
            type.add("\n习题类型："+infoAccessService.getType(info.get(6).toString()));
            count.add("\n习题总数："+info.get(7).toString());
        }
        List index=new ArrayList();
        for(int x=1;x<date.size();x++){
              if(date.get(x).equals(date.get(x-1))){
                  index.add(x);
              }
        }
        for(int x=0;x<index.size();x++){
            date.set(Integer.parseInt(index.get(x).toString()),"");
        }

        info=new ArrayList<>();
        for(int i=count.size()-1;i>=0&&i>count.size()-LargestCount;i--) {
            List<ExpressionWrapper> list0 = infoAccessService.parseRecordFile((int) code.get(i));
            info.add(list0);
            Log.i(null,"info:"+info.toString());
        }
        for(int i=count.size()-1;i>=0&&i>count.size()-LargestCount;i--){
                if (date.get(i).equals("")) {
                    String record = timecost.get(i).toString() + grade.get(i) + wrong.get(i) + (String)type.get(i) + count.get(i);
                    data.add(record);
                    PracticePageFragment.setExpList(info.get(i));
                } else {
                    data.add(date.get(i).toString());
                    String record = timecost.get(i).toString() + grade.get(i) + wrong.get(i) +(String)type.get(i) + count.get(i);
                    data.add(record);
                    PracticePageFragment.setExpList(info.get(i));
                }
        }
        arrayAdapter = new ArrayAdapter(this,R.layout.layout_list,R.id.tvcslayout,data);
        recordshow=this.<ListView>findViewById(R.id.record_show);
        recordshow.setAdapter (arrayAdapter);

        recordshow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                              @Override
                                              public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                                  Log.i(null,"click");

                                              }
                                          }


        );
        hasAdd=new boolean[data.size()];
   }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        int pos=recordshow.getFirstVisiblePosition();
        int index=0;
        while(pos<data.size()){
            if(data.get(pos).length()>12){
                if(!hasAdd[pos]){
                    hasAdd[pos]=true;

                    LinearLayout layout=(LinearLayout)recordshow.getChildAt(pos);
                    Button button=new Button(getBaseContext());
                    button.setText("再次练习");
                    int finalPos = index;
                    button.setBackgroundColor(Color.parseColor("#CABDA2"));
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            PracticePageFragment.initialData();
                            PracticePageFragment.setExpList(info.get(finalPos));
                            Intent intent=new Intent(getBaseContext(),PracticeActivity.class);
                            startActivity(intent);
                        }
                    });
                    layout.addView(button);
                }
                index++;
            }
            pos++;
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull String name, @NonNull Context context, @NonNull AttributeSet attrs) {

        return super.onCreateView(name, context, attrs);
    }

    public void myClick(View view) {

    }

}