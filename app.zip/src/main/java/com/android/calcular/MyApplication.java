package com.android.calcular;

/**
 * project name: Calcular
 * Date 2021/10/23 12:41
 *
 * @PackageName: com.android.calcular
 * @ClassName: MyApplication
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
public class MyApplication extends Application {
    @SuppressLint("StaticFieldLeak")
    /**
     * 静态context
     */
    public static Context context;

    /**
     *@Params: []
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 23:20
     *@Desciption: 用于获取Context
     */
    @Override
    public void onCreate() {
        super.onCreate();
        context=getApplicationContext();
    }
}

