package com.android.calcular;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.android.calcular.adapter.ViewPageAdapter;
import com.android.calcular.ui.GuideFragment1;
import com.android.calcular.ui.GuideFragment2;
import com.android.calcular.ui.GuideFragment3;
import com.android.calcular.ui.GuideFragment4;
import com.android.calcular.ui.HomeFragment;
import com.android.calcular.ui.MineFragment;
import com.android.calcular.ui.PracticeFragment;

import java.util.ArrayList;
import java.util.List;

public class GuideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        getSupportActionBar().hide();
        ViewPager2 viewPager2=findViewById(R.id.viewPage_guide);
        List<Fragment> fragmentList=new ArrayList<Fragment>();
        fragmentList.add(new GuideFragment1());
        fragmentList.add(new GuideFragment2());
        fragmentList.add(new GuideFragment3());
        fragmentList.add(new GuideFragment4());
        viewPager2.setAdapter(ViewPageAdapter.start(this,fragmentList));
        viewPager2.setOffscreenPageLimit(1);
    }
}