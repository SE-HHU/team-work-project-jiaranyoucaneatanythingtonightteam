package com.android.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.calcular.control.PracticeAction;
import com.android.calcular.preference.Arguments;
import com.android.calcular.service.ArgumentWrapper;
import com.android.calcular.service.InfoAccessService;
import com.android.calcular.ui.PracticePageFragment;

import java.util.List;

public class RecommendActivity extends AppCompatActivity {
    private TextView textView1;
    private TextView textView2;
    private TextView textView3;
    private Button button1;
    private Button button2;
    private Button button3;
    private static List<String> types;

    public static void setTypes(List<String> type){
        types=type;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend);
        setTitle("今日推荐");
        textView1=findViewById(R.id.textView_recommend1);
        textView2=findViewById(R.id.textView_recommend2);
        textView3=findViewById(R.id.textView_recommend3);
        button1=findViewById(R.id.button_r1);
        button2=findViewById(R.id.button_r2);
        button3=findViewById(R.id.button_r3);
        textView1.setText(types.get(0));
        textView2.setText(types.get(1));
        textView3.setText(types.get(2));
        InfoAccessService infoAccessService=new InfoAccessService(this);
        button1.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this);
            practiceAction.startGenerating(selectArg(types.get(0)));
            PracticePageFragment.initialData();
            Intent intent=new Intent(this,PracticeActivity.class);
            startActivity(intent);
        });
        button2.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this);
            practiceAction.startGenerating(selectArg(types.get(1)));
            PracticePageFragment.initialData();
            Intent intent=new Intent(this,PracticeActivity.class);
            startActivity(intent);
        });
        button3.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this);
            practiceAction.startGenerating(selectArg(types.get(2)));
            PracticePageFragment.initialData();
            Intent intent=new Intent(this,PracticeActivity.class);
            startActivity(intent);
        });
    }

    private ArgumentWrapper selectArg(String type){
        Log.i("type",type);
        ArgumentWrapper argumentOral=null;
        String oralType;
        switch(type){
            case "5以内加法":
                argumentOral= Arguments.ARG_ORAL_1_1;
                oralType="11";
                break;
            case "5以内减法":
                argumentOral= Arguments.ARG_ORAL_1_2;
                oralType="12";
                break;
            case "10以内加减法":
                argumentOral= Arguments.ARG_ORAL_1_3;
                oralType="13";
                break;
            case "10以内连加、连减":
                argumentOral= Arguments.ARG_ORAL_1_4;
                oralType="14";
                break;
            case "10以内加减混合":
                argumentOral= Arguments.ARG_ORAL_1_5;
                oralType="15";
                break;
            case "20以内加减混合":
                argumentOral= Arguments.ARG_ORAL_1_6;
                oralType="16";
                break;
            case "100以内的加减混合":
                argumentOral= Arguments.ARG_ORAL_1_7;
                oralType="17";
                break;
            case "100以内的减法":
                argumentOral= Arguments.ARG_ORAL_1_8;
                oralType="18";
                break;
            case "100以内的加法":
                argumentOral= Arguments.ARG_ORAL_1_9;
                oralType="19";
                break;


            case "加法，减法，混合加减":
                argumentOral=Arguments.ARG_ORAL_2_1;
                oralType="21";
                break;
            case "9x9乘法":
                argumentOral=Arguments.ARG_ORAL_2_2;
                oralType="22";
                break;
            case "10以内乘加，乘减":
                argumentOral=Arguments.ARG_ORAL_2_3;
                oralType="23";
                break;
            case "100以内除以个位数。得数需为整数":
                argumentOral=Arguments.ARG_ORAL_2_4;
                oralType="24";
                break;
            case "除加，除减":
                argumentOral=Arguments.ARG_ORAL_2_5;
                oralType="25";
                break;
            case "100-1000的加减法":
                argumentOral=Arguments.ARG_ORAL_2_6;
                oralType="26";
                break;

            case "一位数除两位数，结果为整数":
                argumentOral=Arguments.ARG_ORAL_3_1;
                oralType="31";
                break;
            case "一位数除三位数，结果为整数":
                argumentOral=Arguments.ARG_ORAL_3_2;
                oralType="32";
                break;
            case "两位数乘一位数":
                argumentOral=Arguments.ARG_ORAL_3_3;
                oralType="33";
                break;
            case "两位数相乘":
                argumentOral=Arguments.ARG_ORAL_3_4;
                oralType="34";
                break;
            case "含小数的加减法":
                argumentOral=Arguments.ARG_ORAL_3_5;
                oralType="35";
                break;

            case "含括号的三运算符":
                argumentOral=Arguments.ARG_ORAL_4_1;
                oralType="41";
                break;
            case "含小数的加，减法":
                argumentOral=Arguments.ARG_ORAL_4_2;
                oralType="42";
                break;

            case "除数是整数,算式可除的小数除法":
                argumentOral=Arguments.ARG_ORAL_5_1;
                oralType="51";
                break;
            case "小数乘，除法":
                argumentOral=Arguments.ARG_ORAL_5_2;
                oralType="52";
                break;
            case "同分母的分数加，减法":
                argumentOral=Arguments.ARG_ORAL_5_3;
                oralType="53";
                break;
            case "异分母的加，减法":
                argumentOral=Arguments.ARG_ORAL_5_4;
                oralType="54";
                break;
            case "含分母的加减混合运算":
                argumentOral=Arguments.ARG_ORAL_5_5;
                oralType="55";
                break;

            case "分数乘整数":
                argumentOral=Arguments.ARG_ORAL_6_1;
                oralType="61";
                break;
            case "分数乘分数":
                argumentOral=Arguments.ARG_ORAL_6_2;
                oralType="62";
                break;

            default:
        }
        argumentOral.setAmount(20);
        return argumentOral;
    }
}