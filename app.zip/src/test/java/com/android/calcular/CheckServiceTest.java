package com.android.calcular;

import android.service.textservice.SpellCheckerService;

import com.android.calcular.service.ArgumentWrapper;
import com.android.calcular.service.CheckerService;
import com.android.calcular.service.FractionWrapper;
import com.android.calcular.service.GeneratorService;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * project name: Calcular
 * Date 2021/10/26 20:36
 *
 * @PackageName: com.android.calcular
 * @ClassName: CheckServiceTest
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class CheckServiceTest {
    @Test
    public void testCheckAnswer(){

        CheckerService checkerService=new CheckerService();
        GeneratorService generatorService=new GeneratorService();
        generatorService.generate(new ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},true,false));
        List<FractionWrapper> list=new ArrayList<>();
        list.add(new FractionWrapper(1));
        list.add(new FractionWrapper(2));
        list.add(new FractionWrapper(3));
        checkerService.checkAnswer(generatorService.getList(),list);

    }
}
